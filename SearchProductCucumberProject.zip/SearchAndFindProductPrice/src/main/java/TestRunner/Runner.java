package TestRunner;

import org.junit.runner.RunWith;
import org.testng.annotations.DataProvider;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.TestNGCucumberRunner;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/main/java/Features", glue="stepDefinitions",stepNotifications=true, plugin = {"pretty", "html:target/login_report.html", "json:target/login_JSOn_report.json"})
public class Runner {
	
}
