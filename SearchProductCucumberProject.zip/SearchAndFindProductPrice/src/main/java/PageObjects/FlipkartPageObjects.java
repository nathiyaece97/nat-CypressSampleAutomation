package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class FlipkartPageObjects {
	
	static WebDriver driver;
	
	public FlipkartPageObjects(WebDriver driver){
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//span[text()='Login']")
	public WebElement loginPopup;
	
	@FindBy(xpath="//span[text()='Login']//preceding::button[1]")
	public WebElement closeLoginPopup;
	
	@FindBy(xpath="//input[@name='q']")
	public WebElement searchtxtbx;
	
	@FindBy(xpath="//input[@name='q']//following::button[1]")
	public WebElement searchIcon;
	
	@FindBy(xpath="(//div[contains(@class,'col-5')]/div[1]/div)[1]/div[1]")
	public WebElement productprice;
	
	String productname = "//div[text()='xxx']";
	public WebElement returnProduct(String product) {
		return driver.findElement(By.xpath(productname.replaceAll("xxx", product)));
	}
	
}
