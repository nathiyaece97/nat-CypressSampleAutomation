package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonPageObjects {
	
	static WebDriver driver;
	
	public AmazonPageObjects(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="twotabsearchtextbox")
	public WebElement searchtxtbx;
	
	@FindBy(id="nav-search-submit-button")
	public WebElement searchIcon;
	
	String productname = "//span[contains(text(),'xxx')]";
	public WebElement returnProduct(String product) {
		return driver.findElement(By.xpath(productname.replaceAll("xxx", product)));
	}
	
	@FindBy(xpath="//div[contains(@class,'s-search-results')][2]/div//h2/a/span")
	public List<WebElement> productnames;
	
	@FindBy(xpath="//div[contains(@class,'s-search-results')][2]/div//span[@class='a-price']/span[2]/span[2]")
	public List<WebElement> productPrices;
	
	
	
	
	//(//span[contains(text(),'realme C11 (2021) (Cool Blue, 2GB RAM, 32GB Storage)')]//following::div[3]//span/span)[1]
		
	

}
