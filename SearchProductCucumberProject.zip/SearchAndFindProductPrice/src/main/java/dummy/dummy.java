package dummy;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class dummy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String excelpath = System.getProperty("user.dir")+"\\DataTable\\DataTable_product.xlsx";
				System.out.println(excelpath);
		try {
			
			FileInputStream file=new FileInputStream(excelpath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			System.out.println(sheet.getSheetName());
			System.out.println( sheet.getRow(1).getCell(0).getStringCellValue());		
			
		}catch(Exception e) {
			e.getStackTrace();
		}
	}

}
