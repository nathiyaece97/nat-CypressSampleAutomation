package Utilities;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReusableFunctions {

	/*static WebDriver driver=null;
	public WebDriver launchDriver(String url) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		return driver;
		
	} */
	
	
	public static String readDataFromExcel(int row, int col) {
		
		String data="";
		String excelpath = System.getProperty("user.dir")+"\\DataTable\\DataTable_product.xlsx";
		try {
			
			FileInputStream file=new FileInputStream(excelpath);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			data = sheet.getRow(row).getCell(col).getStringCellValue();		
			
		}catch(Exception e) {
			e.getStackTrace();
		}
		return data;
		
	}
	
	

}
