package stepDefinitions;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.AmazonPageObjects;
import PageObjects.FlipkartPageObjects;
import Utilities.ReusableFunctions;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	
	static ReusableFunctions reuseobj = new ReusableFunctions();
	
	static WebDriver driver;
	FlipkartPageObjects flippageobj;
	AmazonPageObjects amazonpageObj;
	static String flipkartProductPrice = "";
	static String amazonProductPrice = "";
	static String product = reuseobj.readDataFromExcel(1,0);
	
// ********** Using before Hooks to execute this method before to all other methods ****************
	@Before public void launchDriver() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		flippageobj = new FlipkartPageObjects(driver);
		amazonpageObj = new AmazonPageObjects(driver);
	}
	
//*******************************************  Launch the Flipkart Website ************************************
	
	@Given("User is in the Flipkart Home screen")
	public void user_is_in_the_flipkart_home_screen() {
		try {
			String url = "https://www.flipkart.com/";
			driver.get(url);
		}
		catch(Exception e) {
			System.out.println("Flipkart not launched");
		}  
	}

// **************************************** Search and Find Product Price in Flipkart ************************
	
	@When("Search for the product and get the product price in Flipkart")
	public void search_for_the_product_and_get_the_product_price() throws Exception {
		
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			
			// To close the login popup
			if(flippageobj.loginPopup.isDisplayed()) {
				flippageobj.closeLoginPopup.click();
			}
			
			//Search and find the product
		    flippageobj.searchtxtbx.sendKeys(product);
		    flippageobj.searchIcon.click();
		    Thread.sleep(5000);
		    flipkartProductPrice =flippageobj.productprice.getText(); 
		    flipkartProductPrice = flipkartProductPrice.substring(1,flipkartProductPrice.length());
		}
		catch(Exception e) {
			System.out.println("Product search not successful");
		}
	}
	
	
// ********************************************* Login to Amazon Page ***********************************
	
	@Given("User is in the Amazon Home screen")
	public void user_is_in_the_Amazon_home_screen() {
		String url = "https://www.amazon.in/";
		driver.get(url);
	    
	}
	
// ******************************************** Search and Find Product price *******************************
	
	 @When("^Search for the product (.+) and get the product price in Amazon$")
	    public void search_for_the_product_and_get_the_product_price_in_amazon(String product) throws Throwable {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		amazonpageObj.searchtxtbx.sendKeys(product);
		amazonpageObj.searchIcon.click();
		
		//Find the correct product
		List<WebElement> productlist = amazonpageObj.productnames;
		for(int i=0;i<productlist.size();i++) {
			String productname = productlist.get(i).getText();
			if(productname.contains(product)) {
				amazonProductPrice = amazonpageObj.productPrices.get(i).getText();
				break;
			}
			
		}
	}
	
// **************************** Compare and Find cheaper product **************************************************

    @Then("^Compare and Find the product with cheaper price$")
    public void compare_and_find_the_product_with_cheaper_price() throws Throwable {
    	
    	int amazonprice = Integer.parseInt(amazonProductPrice.replaceAll(",", ""));
    	int flipkartprice = Integer.parseInt(flipkartProductPrice.replaceAll(",", ""));
    	
       if(amazonprice<flipkartprice) {
    	   System.out.println(" ***** Product price is less in Amazon. Price in Amazon : "+amazonProductPrice +" Price in Flipkart : "+flipkartprice+" *****");
       }
       else if(amazonprice>flipkartprice){
    	   System.out.println(" ***** Product price is less in Flipkart.  Price in Amazon : "+amazonProductPrice +" Price in Flipkart : "+flipkartprice+" *****");
    	   
       }
       else {
    	   System.out.println(" ***** Product price is same in both the websites. Price : "+flipkartProductPrice +" *****"); 
       } 
    	
  
    }
    
 // **********************************************Using after hooks to Close the browser *************************************
	
 	@After
 	public void close_the_browser() {
 	  driver.close();
 	}

	





}
